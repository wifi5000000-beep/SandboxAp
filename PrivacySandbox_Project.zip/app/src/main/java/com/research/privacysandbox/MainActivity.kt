package com.research.privacysandbox

import android.annotation.SuppressLint
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.graphics.Bitmap
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.research.privacysandbox.data.AppDatabase
import com.research.privacysandbox.data.ProfileEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.TimeZone

class MainActivity : ComponentActivity() {

    private lateinit var database: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        database = AppDatabase.getDatabase(this)

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    MainScreen(database)
                }
            }
        }
    }

    fun realignSystemTimezone(targetTimezoneId: String) {
        val timeZone = TimeZone.getTimeZone(targetTimezoneId)
        TimeZone.setDefault(timeZone)
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun MainScreen(database: AppDatabase) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var profiles by remember { mutableStateOf(emptyList<ProfileEntity>()) }
    var activeProfile by remember { mutableStateOf<ProfileEntity?>(null) }

    var label by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("https://browserleaks.com/canvas") }
    var host by remember { mutableStateOf("127.0.0.1") }
    var port by remember { mutableStateOf("1080") }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var timezone by remember { mutableStateOf("America/New_York") }

    LaunchedEffect(Unit) {
        database.profileDao().getAllProfiles().collect { profilesList ->
            profiles = profilesList
        }
    }

    if (activeProfile != null) {
        Box(modifier = Modifier.fillMaxSize()) {
            AndroidView(factory = { ctx ->
                WebView(ctx).apply {
                    settings.apply {
                        javaScriptEnabled = true
                        domStorageEnabled = true
                        databaseEnabled = true
                        cacheMode = WebSettings.LOAD_NO_CACHE
                        mediaPlaybackRequiresUserGesture = false
                    }

                    webViewClient = object : WebViewClient() {
                        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                            super.onPageStarted(view, url, favicon)
                            val jsInjection = """
                                Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
                                Object.defineProperty(navigator, 'hardwareConcurrency', { get: () => 8 });
                                Object.defineProperty(navigator, 'deviceMemory', { get: () => 8 });
                                
                                const originalGetImageData = CanvasRenderingContext2D.prototype.getImageData;
                                CanvasRenderingContext2D.prototype.getImageData = function(x, y, width, height) {
                                    const imageData = originalGetImageData.apply(this, arguments);
                                    for (let i = 0; i < imageData.data.length; i += 4) {
                                        const noise = \${activeProfile!!.id} % 3; 
                                        imageData.data[i] = Math.min(255, imageData.data[i] + noise); 
                                        imageData.data[i+1] = Math.max(0, imageData.data[i+1] - noise);
                                    }
                                    return imageData;
                                };
                            """.trimIndent()
                            view?.evaluateJavascript(jsInjection, null)
                        }
                    }
                    loadUrl(activeProfile!!.targetUrl)
                }
            }, modifier = Modifier.fillMaxSize())

            Button(
                onClick = { activeProfile = null },
                modifier = Modifier.padding(16.dp)
            ) {
                Text("Close Session")
            }
        }
    } else {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Profile Sandbox Setup", style = MaterialTheme.typography.headlineMedium)
            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(value = label, onValueChange = { label = it }, label = { Text("Custom Label") })
            OutlinedTextField(value = url, onValueChange = { url = it }, label = { Text("Target URL") })
            Row {
                OutlinedTextField(value = host, onValueChange = { host = it }, label = { Text("Proxy Host") }, modifier = Modifier.weight(1f))
                Spacer(modifier = Modifier.width(8.dp))
                OutlinedTextField(value = port, onValueChange = { port = it }, label = { Text("Port") }, modifier = Modifier.weight(1f))
            }
            Row {
                OutlinedTextField(value = user, onValueChange = { user = it }, label = { Text("User") }, modifier = Modifier.weight(1f))
                Spacer(modifier = Modifier.width(8.dp))
                OutlinedTextField(value = pass, onValueChange = { pass = it }, label = { Text("Pass") }, modifier = Modifier.weight(1f))
            }
            OutlinedTextField(value = timezone, onValueChange = { timezone = it }, label = { Text("Target Timezone") })

            Button(
                onClick = {
                    coroutineScope.launch(Dispatchers.IO) {
                        database.profileDao().insertProfile(
                            ProfileEntity(
                                customLabel = label,
                                targetUrl = url,
                                proxyHost = host,
                                proxyPort = port.toIntOrNull() ?: 1080,
                                proxyUser = user,
                                proxyPass = pass,
                                targetTimezone = timezone
                            )
                        )
                    }
                },
                modifier = Modifier.padding(top = 16.dp, bottom = 16.dp)
            ) {
                Text("Register Profile")
            }

            HorizontalDivider()

            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(profiles) { profile ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(profile.customLabel, style = MaterialTheme.typography.titleLarge)
                            Text("Target: \${profile.targetUrl}")
                            Text("Proxy: \${profile.proxyHost}:\${profile.proxyPort}")
                            Text("Timezone: \${profile.targetTimezone}")
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Button(onClick = {
                                    (context as MainActivity).realignSystemTimezone(profile.targetTimezone)
                                    val vpnIntent = VpnService.prepare(context)
                                    if (vpnIntent == null) {
                                        val startVpn = Intent(context, com.research.privacysandbox.service.SocksVpnService::class.java).apply {
                                            action = com.research.privacysandbox.service.SocksVpnService.ACTION_START_VPN
                                            putExtra(com.research.privacysandbox.service.SocksVpnService.EXTRA_HOST, profile.proxyHost)
                                            putExtra(com.research.privacysandbox.service.SocksVpnService.EXTRA_PORT, profile.proxyPort)
                                        }
                                        context.startService(startVpn)
                                    }
                                    activeProfile = profile
                                }) {
                                    Text("Launch Session")
                                }

                                OutlinedButton(onClick = {
                                    coroutineScope.launch(Dispatchers.IO) {
                                        database.profileDao().deleteProfile(profile)
                                    }
                                }) {
                                    Text("Delete")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}