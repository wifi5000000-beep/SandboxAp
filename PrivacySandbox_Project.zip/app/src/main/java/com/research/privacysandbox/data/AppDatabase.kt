package com.research.privacysandbox.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "proxy_profiles")
data class ProfileEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    @ColumnInfo(name = "custom_label") val customLabel: String,
    @ColumnInfo(name = "target_url") val targetUrl: String,
    @ColumnInfo(name = "proxy_host") val proxyHost: String,
    @ColumnInfo(name = "proxy_port") val proxyPort: Int,
    @ColumnInfo(name = "proxy_user") val proxyUser: String,
    @ColumnInfo(name = "proxy_pass") val proxyPass: String,
    @ColumnInfo(name = "target_timezone") val targetTimezone: String
)

@Dao
interface ProfileDao {
    @Query("SELECT * FROM proxy_profiles ORDER BY id DESC")
    fun getAllProfiles(): Flow<List<ProfileEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfile(profile: ProfileEntity)

    @Delete
    suspend fun deleteProfile(profile: ProfileEntity)
}

@Database(entities = [ProfileEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun profileDao(): ProfileDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "sandbox_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}