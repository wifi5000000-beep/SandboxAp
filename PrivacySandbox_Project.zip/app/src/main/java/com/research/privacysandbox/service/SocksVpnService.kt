package com.research.privacysandbox.service

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.util.Log
import kotlinx.coroutines.*
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer

class SocksVpnService : VpnService() {

    private var vpnInterface: ParcelFileDescriptor? = null
    private val serviceJob = Job()
    private val serviceScope = CoroutineScope(Dispatchers.IO + serviceJob)

    companion object {
        const val ACTION_START_VPN = "com.research.privacysandbox.START_VPN"
        const val ACTION_STOP_VPN = "com.research.privacysandbox.STOP_VPN"
        const val EXTRA_HOST = "extra_host"
        const val EXTRA_PORT = "extra_port"
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_VPN -> {
                val host = intent.getStringExtra(EXTRA_HOST) ?: "127.0.0.1"
                val port = intent.getIntExtra(EXTRA_PORT, 1080)
                startVpnTunnel(host, port)
            }
            ACTION_STOP_VPN -> stopVpnTunnel()
        }
        return START_STICKY
    }

    private fun startVpnTunnel(proxyHost: String, proxyPort: Int) {
        if (vpnInterface != null) return

        try {
            val builder = Builder()
                .addAddress("10.0.0.2", 24)
                .addRoute("0.0.0.0", 0)
                .setSession("SandboxSocksTunnel")
                .setMtu(1500)
            
            try {
                builder.addAllowedApplication(packageName)
                builder.addAllowedApplication("com.android.vending")
            } catch (e: Exception) {
                Log.e("SocksVpnService", "Failed to add allowed application", e)
            }

            vpnInterface = builder.establish()

            vpnInterface?.let { fd ->
                serviceScope.launch {
                    processPackets(fd, proxyHost, proxyPort)
                }
            }
        } catch (e: Exception) {
            Log.e("SocksVpnService", "Error configuring VPN interface", e)
        }
    }

    private suspend fun processPackets(vpnFileDescriptor: ParcelFileDescriptor, host: String, port: Int) {
        val inputStream = FileInputStream(vpnFileDescriptor.fileDescriptor)
        val outputStream = FileOutputStream(vpnFileDescriptor.fileDescriptor)
        val packet = ByteBuffer.allocate(32767)

        try {
            while (isActive) {
                val length = inputStream.read(packet.array())
                if (length > 0) {
                    packet.limit(length)
                    packet.clear()
                }
            }
        } catch (e: Exception) {
            Log.e("SocksVpnService", "Packet processing interrupted", e)
        } finally {
            inputStream.close()
            outputStream.close()
        }
    }

    private fun stopVpnTunnel() {
        serviceJob.cancelChildren()
        try {
            vpnInterface?.close()
        } catch (e: Exception) {
            Log.e("SocksVpnService", "Error closing VPN interface", e)
        }
        vpnInterface = null
        stopSelf()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopVpnTunnel()
        serviceJob.cancel()
    }
}